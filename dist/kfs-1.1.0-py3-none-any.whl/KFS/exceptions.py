# Copyright (c) 2023 구FS, all rights reserved. Subject to the MIT licence in `licence.md`.
class ConversionError(Exception):   # KFS::media::convert_images_to_PDF(...)
    pass